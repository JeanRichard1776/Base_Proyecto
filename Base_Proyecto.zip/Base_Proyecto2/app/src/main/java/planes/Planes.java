package planes;

public class Planes {
    private int xTreme;
    private  int mindfullness;

    public Planes()
    {
        xTreme=12000;
        mindfullness=24000;
    }

    public int getxTreme() {
        return xTreme;
    }

    public int getMindfullness() {
        return mindfullness;
    }
}
