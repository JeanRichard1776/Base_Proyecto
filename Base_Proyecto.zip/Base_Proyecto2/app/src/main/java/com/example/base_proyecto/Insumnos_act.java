package com.example.base_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import clases.AdminSQLiteOpenHelper;

public class Insumnos_act extends AppCompatActivity {
    private EditText edcodigo,ednombre,edprecio,edstock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insumnos_act);

        edcodigo=(EditText)findViewById(R.id.etcode);
        ednombre=(EditText)findViewById(R.id.etnombre);
        edprecio=(EditText)findViewById(R.id.etprecio);
        edstock=(EditText)findViewById(R.id.etstock);
    }

    public void AnadirInsumno(View view)
    {
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this,"fichero",null,1);
        SQLiteDatabase sqLiteDatabase=admin.getWritableDatabase();
        String codigo=edcodigo.getText().toString();

        if (!codigo.isEmpty())
        {
            ContentValues cont=new ContentValues();
            cont.put("codigo",edcodigo.getText().toString());
            cont.put("nombre",ednombre.getText().toString());
            cont.put("precio",edprecio.getText().toString());
            cont.put("stock",edstock.getText().toString());

            sqLiteDatabase.insert("fichero",null,cont);
            sqLiteDatabase.close();
            Toast.makeText(this,"Datos ingresar a la base de datos",Toast.LENGTH_SHORT).show();
        }else
        {
            Toast.makeText(this,"Deberia ingresar un codigo",Toast.LENGTH_SHORT).show();
        }
    }

    public void Mostrar(View view)
    {
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this,"fichero",null,1);
        SQLiteDatabase sqLiteDatabase=admin.getWritableDatabase();

        String codigo=edcodigo.getText().toString();

        if (!codigo.isEmpty())
        {
            Cursor fila=sqLiteDatabase.rawQuery("SELECT nombre,precio,stock FROM insumnos WHERE codigo="+codigo,null);

            if (fila.moveToFirst())
            {
                ednombre.setText(fila.getString(0));
                edprecio.setText(fila.getString(1));
                edstock.setText(fila.getString(2));
            }else {
                Toast.makeText(this,"No hay entidad en el insumno",Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(this,"No hay insumno",Toast.LENGTH_LONG).show();
        }
    }

    public void Eliminar(View view)
    {
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this,"fichero",null,1);
        SQLiteDatabase sqLiteDatabase=admin.getWritableDatabase();

        String codigo=edcodigo.getText().toString();
        sqLiteDatabase.delete("insumnos","codigo"+codigo,null);
        sqLiteDatabase.close();

        Toast.makeText(this,"Haz Eliminado un insumno",Toast.LENGTH_LONG).show();
        edcodigo.setText("");
        ednombre.setText("");
        edprecio.setText("");
        edstock.setText("");
    }

    public  void Actualizar(View view){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this,"fichero",null,1);
        SQLiteDatabase sqLiteDatabase=admin.getWritableDatabase();

        String codigo=edcodigo.getText().toString();

            ContentValues cont = new ContentValues();
            cont.put("codigo",edcodigo.getText().toString());
            cont.put("nombre",ednombre.getText().toString());
            cont.put("precio",edprecio.getText().toString());
            cont.put("stock",edstock.getText().toString());

            if (!codigo.isEmpty()) {
                sqLiteDatabase.update("insumnos",cont,"codigo"+codigo,null);
                sqLiteDatabase.close();

                Toast.makeText(this,"Haz actualizado los datos",Toast.LENGTH_LONG).show();
        }
    }

}